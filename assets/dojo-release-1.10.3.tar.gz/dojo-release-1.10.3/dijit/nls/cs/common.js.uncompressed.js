define(
"dijit/nls/cs/common", ({
	buttonOk: "OK",
	buttonCancel: "Storno",
	buttonSave: "Uložit",
	itemClose: "Zavřít"
})
);

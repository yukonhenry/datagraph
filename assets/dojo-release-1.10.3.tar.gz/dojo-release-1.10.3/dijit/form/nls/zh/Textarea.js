//>>built
define("dijit/form/nls/zh/Textarea",({iframeEditTitle:"编辑区域",iframeFocusTitle:"编辑区域框"}));
